package com.example.aptech.greenfox;

/**
 * Created by aptech on 20-Oct-20.
 */

public class Urls {

    //private String base_url = "http://192.168.1.102:82/";
    private String base_url = "http://greenfox-android-app.rehmattechnologies.net/";

    public String url_processing()
    {
        //return base_url + "greenfox-android-app/php/process.php";
        return base_url + "php/process.php";
    }

}
