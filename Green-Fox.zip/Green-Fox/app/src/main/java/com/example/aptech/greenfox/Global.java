package com.example.aptech.greenfox;

public class Global {

    public static itemDetails  itemDetails = new itemDetails();

}
